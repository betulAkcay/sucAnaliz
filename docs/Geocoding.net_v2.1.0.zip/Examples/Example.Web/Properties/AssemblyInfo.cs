﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("GeoCoding Example Website")]
[assembly: AssemblyProduct("GeoCoding.Net")]
[assembly: AssemblyCompany("GeoCoding.Net")]
[assembly: AssemblyCopyright("Copyright © 2008 - 2012 Chad Lee")]
[assembly: AssemblyConfiguration("Debug")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("2.1.0.0")]
[assembly: AssemblyFileVersion("2.1.0.0")]